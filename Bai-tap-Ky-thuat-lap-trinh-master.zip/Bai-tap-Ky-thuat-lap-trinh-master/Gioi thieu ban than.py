print(" Hello Teacher ! ")
print(" Nguyễn Quốc Chung, MSSV: 18575202160010, Ngành: KTĐK & TĐH")