def chuyen_chu_hoa(n):
   print('Sau khi chuyển là :'+ n.upper())
chuyen_chu_hoa(" hello world ")